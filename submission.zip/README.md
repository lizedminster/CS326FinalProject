# CS326FinalProject
This is the final project of UMass CompSci326: Web Programming. It is a trivia based virtual Gacha machine. 
