const trivia = [
    {
        "question": "What is 2 * 1?",
        "correct": "2",
        "points": "10"
    },
    {
        "question": "What is 2 + 2?",
        "correct": "4",
        "points": "10"
    },
    {
        "question": "What is sin(pi)?",
        "correct": "0",
        "points": "20"
    },
    {
        "question": "What is the derivative of 9x?",
        "correct": "9",
        "points": "20"
    },
    {
        "question": "What is x in 3x + 1 = 10?",
        "correct": "3",
        "points": "20"
    },
    {
        "question": "What is ln(e)?",
        "correct": "1",
        "points": "25"
    },
    {
        "question": "What is the positive square root of 100?",
        "correct": "10",
        "points": "25"
    }
]

export { trivia }