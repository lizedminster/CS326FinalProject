const users = [
    {
        "username": "liz",
        "password": "123"
    },
    {
        "username": "abby",
        "password": "abc"
    },
    {
        "username": "tina",
        "password": "321"
    },
    {
        "username": "vivi",
        "password": "cda"
    },
    {
        "username": "olga",
        "password": "xxx"
    },
    {
        "username": "vera",
        "password": "yyy"
    },
    {
        "username": "lily",
        "password": "zzz"
    }

]

export { users };